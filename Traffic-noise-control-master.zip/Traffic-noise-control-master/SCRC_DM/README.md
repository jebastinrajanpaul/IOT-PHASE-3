# SCRC_DM
Device Management Layer for SCRC lab
